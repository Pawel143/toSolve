package com.example.carsharing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaeSharingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaeSharingApplication.class, args);
	}

}
