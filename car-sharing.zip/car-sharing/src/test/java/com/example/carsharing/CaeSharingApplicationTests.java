package com.example.carsharing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaeSharingApplicationTests {

	@Test
	void contextLoads() {
	}

}
